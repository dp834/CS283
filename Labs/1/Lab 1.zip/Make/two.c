#include "one.h"
int three();

int two ()
 {
  printf("two\n");
  three();
  return(1);
 }
 