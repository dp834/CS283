#define EXT 6
int main(), one(), two(), three();
