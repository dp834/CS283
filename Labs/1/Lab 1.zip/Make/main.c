//all .c files print but none import stdio.h
//all files include one.h can put stdio there
#include "one.h"
#include "ext.h"


int main ()
 {
  printf("main\n");
  one();
  return(1);
 }
 
