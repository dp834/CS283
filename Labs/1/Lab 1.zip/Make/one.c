#include "one.h" //pointless include as file doesn't exist and is empty when created
#include "ext.h"

int one ()
 {
  printf("one\n");
  two();
  return(1);
 }
 
