#include "one.h"

int three ()
 {
  printf("three\n");
  return(1);
 }
 