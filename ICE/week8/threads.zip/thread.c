#include "csapp.h"

void * do_work (void * arg);

struct AR
 {
  double *array;
  int size;
  double *sum;
 };

int main (int argc, char * argv) 
 {
  double array[100];
  double sum;
  pthread_t id;
  struct AR * arg;
  void  *return_value;
  int i;
  
  for (i = 0; i < 100; i++) array[i] = i;

  arg = (struct AR * ) calloc (1, sizeof (struct AR) ) ;
  arg -> array = array;
  arg -> size = 100;
  arg -> sum = &sum;

  if (pthread_create (&id, NULL, do_work, (void * ) arg) ) 
   {
    fprintf (stderr, "Error\n") ;
    exit (1) ;
   }
  if (pthread_join(id, &return_value))
   {
    fprintf(stderr,"Error\n");
    exit(1);
   }
  printf("sum = %10.1lf\n",sum);
  return(0);
 }

void * do_work (void * arg) 
 {
  struct AR * argument;
  int i, size;
  double * array;
  double * sum;

  argument = (struct AR * ) arg;

  size = argument -> size;
  array = argument -> array;
  sum = argument -> sum;

  * sum = 0;
  for (i = 0; i < size; i ++ ) 
   *sum += array[i];

  return NULL;
 }


